package www.dream.hello.ctler;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import www.dream.hello.model.MemberVO;

@RestController
@RequestMapping("/rapi")
public class Zdfxhgfsgfn {
	@Value("${news.imgdir}")
	String myConfig;
	
	// rapi/fguvb?trt=htfvtv
	@GetMapping("/fguvb")
	public List<String> jyhfvbiyut(@RequestParam(value = "trt") String msg) {
		List<String> ret = new ArrayList<>();
		IntStream.range(0, 10).forEach(val->ret.add(myConfig + val + msg));
		return ret; 
	}

	@GetMapping("/member/all")
	public List<MemberVO> listAllMembers(@RequestParam(value = "trt") String msg) {
		List<MemberVO> ret = new ArrayList<>();
		IntStream.range(0, 10).forEach(val->ret.add(new MemberVO(msg + val, val, "mjghbho;")));
		return ret; 
	}

	@GetMapping(value="/member/aldfsddl", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public List<MemberVO> listAlsgsdflMembers(@RequestParam(value = "trt") String msg) {
		List<MemberVO> ret = new ArrayList<>();
		IntStream.range(0, 10).forEach(val->ret.add(new MemberVO(msg + val, val, "mjghbho;")));
		return ret; 
	}
}
