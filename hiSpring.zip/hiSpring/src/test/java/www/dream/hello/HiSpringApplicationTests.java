package www.dream.hello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HiSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
